  var Sink = Rx.internals.Sink = (function () {

  }());
